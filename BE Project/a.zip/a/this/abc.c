#include<stdio.h>
void main()
{
	int i;
	printf("hi");
	scanf("%d",&i);
	printf("%d",i);
}
