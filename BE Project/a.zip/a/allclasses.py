class COCOMO():
	time_required=0
	KLOC=0
	work_done=0
	def calculate():
		display()
		
	def display():
	
class Project():
	Proj_name=""
	language=""
	def create(current):
	
	def add_file():
		
	def save():
		coc=COCOMO()
		
	def delete():
		trash = Trash()
		
	def edit():
	
	def execute():

	def Compile():
	
	def debug():
	
	def rename():
	
	
class File():
	file_name=""
	file_ext="" #file extension
	file_path=""
	def create():
	
	def edit():
	
	def save():
	
	def rename():
	
	def delete():
		trash=Trash()
		
	def calldraft():
		draft = new Draft()
		draft.autosave()
		
	def execute():
	
	def Compile():
	
	def debug():
	
		
class Draft():
	def autosave()
		
	def delete()
		trash=Trash()
		
class Trash():
	
