#include<stdio.h>
void main()
{
	printf("Heaven and");
	printf("");
	printf("Hell");
	printf("is on earth");
	printf("\n");
}
